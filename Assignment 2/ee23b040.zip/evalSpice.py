import os
import numpy as np
from collections import defaultdict


def evalSpice(filename):
    if not os.path.isfile(filename):
        raise FileNotFoundError("Please give the name of a valid SPICE file as input")

    fptr = open(filename, "r")  # Loading file contents after ensuring file exists

    lines = fptr.readlines()
    lines = [line.strip("\n").strip() for line in lines]

    circuit_flag = False  # To ensure content only after .circuit is considered
    circuit = []
    valid = "null"  # Ensures .circuit and .end are present

    for line in lines:
        if line == ".end":
            if valid == "started":
                valid = "completed"
            break

        if circuit_flag == True:
            buf = line.split()
            try:
                buf = buf[: buf.index("#")]  # Ignoring the comments
            except ValueError:
                pass
            circuit.append(buf)

        if line == ".circuit":
            circuit_flag = True
            valid = "started"

    if valid != "completed":
        raise ValueError("Malformed circuit file")

    elements = []
    for element in circuit:
        dict = {}
        dict["name"] = element[0]
        dict["type"] = element[0][0]
        dict["nodes"] = (element[1], element[2])  # 1st is +ve and 2nd is -ve terminal
        dict["value"] = float(element[-1])
        elements.append(dict)

    for element in elements:  # Ensures only valid components present
        if element["type"] not in ("V", "I", "R"):
            raise ValueError("Only V, I, R elements are permitted")

    ##### Accounting for any resistors with 0 resistance #####

    change = []
    remove = []
    for element in elements:
        if element["type"] == "R" and element["value"] == 0:
            change.append(list(element["nodes"]))
            remove.append(element)

    for element in remove:  # Removes those resistors with 0 resistance
        elements.remove(element)

    nodemap = defaultdict(set)
    replacemap = {}

    for i, j in change:  # Merges nodes if they are connected by R = 0
        i, j = (replacemap.get(i, i), replacemap.get(j, j))

        nodemap[i].add(j)
        replacemap[j] = i

        if j in nodemap:
            nodemap[i].update(nodemap[j])
            for k in nodemap[j]:
                replacemap[k] = i
            del nodemap[j]

    change = [[key, *nodemap[key]] for key in nodemap]

    for nodes in change:  # Ensures 'GND' always present
        if "GND" in nodes:
            ind = nodes.index("GND")
            nodes[0], nodes[ind] = nodes[ind], nodes[0]

    for nodes in change:
        for element in elements:
            for node in nodes[1:]:
                if node == element["nodes"][0]:
                    element["nodes"] = (nodes[0], element["nodes"][1])
                if node == element["nodes"][1]:
                    element["nodes"] = (element["nodes"][0], nodes[0])

    ########################################################

    n = []
    for element in elements:
        [n.append(node) for node in element["nodes"] if node not in n and node != "GND"]

    I_elements = [element for element in elements if element["type"] == "I"]
    V_elements = [element for element in elements if element["type"] == "V"]

    R_count = sum(1 for element in elements if element["type"] == "R")
    V_count = len(V_elements)
    I_count = len(I_elements)

    A = np.full(
        [len(n) + V_count, len(n) + V_count], 0, dtype=float
    )  # Default value of every entry is 0

    for i in range(len(n)):  # Filling in admittance values
        for j in range(i, len(n)):
            G = 0
            for element in elements:
                if (
                    n[i] in element["nodes"]
                    and n[j] in element["nodes"]
                    and element["type"] == "R"
                ):
                    G += 1 / element["value"]
            if i == j:
                A[i][j] = G
            else:
                A[i][j] = -G

    for i in range(V_count):  # Filling in Voltage sources
        for j in range(len(n)):
            element = V_elements[i]
            if n[j] in element["nodes"] and element["type"] == "V":
                if n[j] == element["nodes"][0]:
                    A[j][i + len(n)] = 1
                elif n[j] == element["nodes"][1]:
                    A[j][i + len(n)] = -1

    for i in range(len(n) + V_count):
        for j in range(i, len(n) + V_count):
            A[j, i] = A[i, j]

    if np.linalg.det(A) == 0:  # Det(A) = 0 check takes care of most cases
        raise ValueError("Circuit error: no solution")

    b = np.full(len(n) + V_count, 0, dtype=float)

    for i in range(len(n)):  # Filling in current sources
        for element in I_elements:
            if n[i] == element["nodes"][0]:
                b[i] -= element["value"]
            elif n[i] == element["nodes"][1]:
                b[i] += element["value"]

    for i, V_element in enumerate(V_elements):
        b[i + len(n)] = V_element["value"]

    x = np.linalg.solve(A, b)

    Voltages = {}  # Creating output dictionary from x
    Currents = {}
    Voltages["GND"] = 0
    for i in range(len(n)):
        Voltages[n[i]] = x[i]
    for i, V_element in enumerate(V_elements):
        Currents[V_element["name"]] = x[i + len(n)]

    for nodes in change:
        for node in nodes[1:]:
            Voltages[node] = Voltages[nodes[0]]

    fptr.close()

    return (Voltages, Currents)